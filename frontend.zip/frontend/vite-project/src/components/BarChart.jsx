// src/components/BarChart.jsx
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Bar } from 'react-chartjs-2';

const BarChart = ({ selectedMonth }) => {
  const [data, setData] = useState([]);

  useEffect(() => {
    axios
      .get(`/api/transactions/barchart`, { params: { month: selectedMonth } })
      .then((res) => setData(res.data))
      .catch((err) => console.error(err));
  }, [selectedMonth]);

  const chartData = {
    labels: data.map((item) => item.range),
    datasets: [
      {
        label: 'Items Count',
        data: data.map((item) => item.count),
        backgroundColor: 'rgba(75, 192, 192, 0.6)',
      },
    ],
  };

  return (
    <section>
      <h2>Bar Chart</h2>
      <Bar data={chartData} />
    </section>
  );
};

export default BarChart;
