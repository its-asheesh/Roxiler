// src/components/PieChart.jsx
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Pie } from 'react-chartjs-2';

const PieChart = ({ selectedMonth }) => {
  const [data, setData] = useState([]);

  useEffect(() => {
    axios
      .get(`/api/transactions/piechart`, { params: { month: selectedMonth } })
      .then((res) => setData(res.data))
      .catch((err) => console.error(err));
  }, [selectedMonth]);

  const chartData = {
    labels: data.map((item) => item._id),
    datasets: [
      {
        label: 'Categories',
        data: data.map((item) => item.count),
        backgroundColor: [
          'rgba(255, 99, 132, 0.6)',
          'rgba(54, 162, 235, 0.6)',
          'rgba(255, 206, 86, 0.6)',
          'rgba(75, 192, 192, 0.6)',
        ],
      },
    ],
  };

  return (
    <section>
      <h2>Pie Chart</h2>
      <Pie data={chartData} />
    </section>
  );
};

export default PieChart;