// src/components/Statistics.jsx
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Statistics = ({ selectedMonth }) => {
  const [stats, setStats] = useState({});

  useEffect(() => {
    axios
      .get(`/api/transactions/statistics`, { params: { month: selectedMonth } })
      .then((res) => setStats(res.data))
      .catch((err) => console.error(err));
  }, [selectedMonth]);

  return (
    <section>
      <h2>Statistics</h2>
      <div>
        <p>Total Sale Amount: ${stats.totalSaleAmount || 0}</p>
        <p>Total Sold Items: {stats.totalSoldItems || 0}</p>
        <p>Total Not Sold Items: {stats.totalNotSoldItems || 0}</p>
      </div>
    </section>
  );
};

export default Statistics;