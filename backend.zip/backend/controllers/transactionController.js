// controllers/transactionController.js
const axios = require('axios');
const Transaction = require('../models/Transaction');

const fetchAndSeedData = async (req, res) => {
  try {
    const { data } = await axios.get('https://s3.amazonaws.com/roxiler.com/product_transaction.json');
    
    // Transform data to match schema
    const transactions = data.map(item => ({
      title: item.title || 'Untitled', // Provide default if missing
      description: item.description || 'No description',
      price: item.price || 0,
      dateOfSale: item.dateOfSale || new Date(),
      isSold: item.isSold !== undefined ? item.isSold : false, // Ensure isSold is provided
      category: item.category || 'Uncategorized',
    }));

    await Transaction.deleteMany();
    await Transaction.insertMany(transactions);

    res.status(200).json({ message: 'Database seeded successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};


const listTransactions = async (req, res) => {
  const { month, search = '', page = 1, perPage = 10 } = req.query;
  const regex = new RegExp(search, 'i');

  const startOfMonth = new Date(`2023-${month}-01`);
  const endOfMonth = new Date(`2023-${month}-31`);

  try {
    const transactions = await Transaction.find({
      dateOfSale: { $gte: startOfMonth, $lte: endOfMonth },
      $or: [
        { title: regex },
        { description: regex },
      ],
    })
      .skip((page - 1) * perPage)
      .limit(perPage);

    res.status(200).json(transactions);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};


const getStatistics = async (req, res) => {
  const { month } = req.query;
  const startOfMonth = new Date(`2023-${month}-01`);
  const endOfMonth = new Date(`2023-${month}-31`);

  try {
    const totalSale = await Transaction.aggregate([
      { $match: { dateOfSale: { $gte: startOfMonth, $lte: endOfMonth } } },
      { $group: { _id: null, total: { $sum: '$price' } } },
    ]);

    const soldItems = await Transaction.countDocuments({
      dateOfSale: { $gte: startOfMonth, $lte: endOfMonth },
      isSold: true,
    });

    const notSoldItems = await Transaction.countDocuments({
      dateOfSale: { $gte: startOfMonth, $lte: endOfMonth },
      isSold: false,
    });

    res.status(200).json({
      totalSaleAmount: totalSale[0]?.total || 0,
      totalSoldItems: soldItems,
      totalNotSoldItems: notSoldItems,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};


const getBarChart = async (req, res) => {
  const { month } = req.query;
  const startOfMonth = new Date(`2023-${month}-01`);
  const endOfMonth = new Date(`2023-${month}-31`);

  try {
    const barChart = await Transaction.aggregate([
      { $match: { dateOfSale: { $gte: startOfMonth, $lte: endOfMonth } } },
      {
        $bucket: {
          groupBy: '$price',
          boundaries: [0, 100, 200, 300, 400, 500, 600, 700, 800, 900, Infinity],
          default: 'Others',
          output: { count: { $sum: 1 } },
        },
      },
    ]);

    res.status(200).json(barChart);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};


const getPieChart = async (req, res) => {
  const { month } = req.query;
  try {
    const categories = await Transaction.aggregate([
      { $match: { dateOfSale: { $regex: `-${month}-` } } },
      { $group: { _id: '$category', count: { $sum: 1 } } },
    ]);
    res.status(200).json(categories);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const getCombinedData = async (req, res) => {
  const { month } = req.query;
  const startOfMonth = new Date(`2023-${month}-01`);
  const endOfMonth = new Date(`2023-${month}-31`);

  try {
    // Statistics
    const totalSale = await Transaction.aggregate([
      { $match: { dateOfSale: { $gte: startOfMonth, $lte: endOfMonth } } },
      { $group: { _id: null, total: { $sum: '$price' } } },
    ]);

    const soldItems = await Transaction.countDocuments({
      dateOfSale: { $gte: startOfMonth, $lte: endOfMonth },
      isSold: true,
    });

    const notSoldItems = await Transaction.countDocuments({
      dateOfSale: { $gte: startOfMonth, $lte: endOfMonth },
      isSold: false,
    });

    const statistics = {
      totalSaleAmount: totalSale[0]?.total || 0,
      totalSoldItems: soldItems,
      totalNotSoldItems: notSoldItems,
    };

    // Bar Chart
    const barChart = await Transaction.aggregate([
      { $match: { dateOfSale: { $gte: startOfMonth, $lte: endOfMonth } } },
      {
        $bucket: {
          groupBy: '$price',
          boundaries: [0, 100, 200, 300, 400, 500, 600, 700, 800, 900, Infinity],
          default: 'Others',
          output: { count: { $sum: 1 } },
        },
      },
    ]);

    // Pie Chart
    const pieChart = await Transaction.aggregate([
      { $match: { dateOfSale: { $gte: startOfMonth, $lte: endOfMonth } } },
      { $group: { _id: '$category', count: { $sum: 1 } } },
    ]);

    // Combined Data
    res.status(200).json({ statistics, barChart, pieChart });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};


module.exports = {
  fetchAndSeedData,
  listTransactions,
  getStatistics,
  getBarChart,
  getPieChart,
  getCombinedData,
};
